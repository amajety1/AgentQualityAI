####################################
# LIBRARIES FOR DATA PREPROCESSING
####################################
# pip install pandas
# pip install numpy
# pip install scipy
# pip install soundfile
# pip install ffmpeg-python
# pip install openai-whisper
# pip install regex
# pip install pyannote.audio
# (If the later does not work, use the one below)
# pip install -qq https://github.com/pyannote/pyannote-audio/archive/refs/heads/develop.zip
# pip install pyannote.core
# pip install torch==1.11.0
# pip install ipython==7.34.0
# pip install tensorflow
# pip install transformers 
# pip install pip install beautifulsoup4
